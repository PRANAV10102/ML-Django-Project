import os
import io
import base64
import joblib
import numpy as np
import pandas as pd

# Avoid font cache permission warnings
os.environ.setdefault('MPLCONFIGDIR', '/tmp/matplotlib_cache')

import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for server environments
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score
)

# Styling for visual plots
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
sns.set_palette("crest")

class LoanMLPipeline:
    """
    Comprehensive Data Mining & ML Pipeline for Loan Approval Prediction.
    Implements all requirements:
    1. Dataset loading & validation
    2. Data Preprocessing:
       - Missing value identification and imputation
       - Outlier detection (IQR / Z-Score) & capping
       - Duplicate removal & irrelevant field dropping
       - Categorical encoding & Feature scaling
       - Feature selection (Correlation & Importance)
    3. Dynamic EDA & Visualizations
    4. Model Training, Evaluation & Real-time Prediction
    """

    CATEGORICAL_COLS = ['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed', 'Property_Area']
    NUMERICAL_COLS = ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term', 'Credit_History']
    TARGET_COL = 'Loan_Status'
    IRRELEVANT_COLS = ['Loan_ID']

    def __init__(self, model_dir=None):
        if model_dir is None:
            model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'trained_models')
        self.model_dir = model_dir
        os.makedirs(self.model_dir, exist_ok=True)
        self.model_path = os.path.join(self.model_dir, 'loan_model_pipeline.joblib')

        self.scaler = None
        self.label_encoders = {}
        self.trained_model = None
        self.model_name = "Random Forest Classifier"
        self.feature_columns = []
        self.feature_importances = {}
        self.iqr_bounds = {}
        self.imputation_values = {}
        self.metrics = {}
        self.training_summary = {}

    def _fig_to_base64(self, fig):
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format='png', dpi=120, bbox_inches='tight')
        buf.seek(0)
        img_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
        plt.close(fig)
        return img_b64

    def load_data(self, file_path_or_buffer):
        """Loads dataset from CSV or Excel file."""
        if isinstance(file_path_or_buffer, str):
            if file_path_or_buffer.endswith('.xlsx') or file_path_or_buffer.endswith('.xls'):
                df = pd.read_excel(file_path_or_buffer)
            else:
                df = pd.read_csv(file_path_or_buffer)
        else:
            # File-like object from Django upload
            name = getattr(file_path_or_buffer, 'name', '')
            if name.endswith('.xlsx') or name.endswith('.xls'):
                df = pd.read_excel(file_path_or_buffer)
            else:
                df = pd.read_csv(file_path_or_buffer)
        return df

    def get_initial_summary(self, df):
        """Computes overview stats for preview table, missing values, and dtypes."""
        total_rows, total_cols = df.shape
        missing_counts = df.isnull().sum().to_dict()
        missing_total = int(df.isnull().sum().sum())
        duplicate_count = int(df.duplicated().sum())

        numeric_summary = df.describe().round(2).to_dict() if len(df.select_dtypes(include=[np.number]).columns) > 0 else {}
        column_types = {col: str(dtype) for col, dtype in df.dtypes.items()}
        preview_rows = df.head(10).to_dict(orient='records')

        return {
            'total_rows': total_rows,
            'total_cols': total_cols,
            'missing_counts': missing_counts,
            'missing_total': missing_total,
            'duplicate_count': duplicate_count,
            'column_types': column_types,
            'preview_rows': preview_rows,
            'columns': list(df.columns),
            'numeric_summary': numeric_summary
        }

    def preprocess_pipeline(self, raw_df, is_training=True):
        """
        Full data preprocessing pipeline:
        1. Remove duplicates
        2. Drop irrelevant columns
        3. Impute missing values (Median/Mode)
        4. Outlier detection & IQR capping
        5. Categorical encoding
        6. Feature scaling
        """
        df = raw_df.copy()
        preprocessing_report = {}

        # 1. Duplicate Removal
        initial_count = len(df)
        df = df.drop_duplicates()
        duplicates_removed = initial_count - len(df)
        preprocessing_report['duplicates_removed'] = duplicates_removed

        # 2. Drop Irrelevant Fields
        dropped_cols = [col for col in self.IRRELEVANT_COLS if col in df.columns]
        if dropped_cols:
            df = df.drop(columns=dropped_cols)
        preprocessing_report['dropped_columns'] = dropped_cols

        # 3. Missing Value Identification & Imputation
        missing_before = df.isnull().sum().to_dict()
        preprocessing_report['missing_before'] = missing_before

        if is_training:
            self.imputation_values = {}
            for col in df.columns:
                if col == self.TARGET_COL:
                    continue
                if df[col].dtype == 'object' or col in self.CATEGORICAL_COLS:
                    mode_val = df[col].mode().iloc[0] if not df[col].mode().empty else 'Missing'
                    self.imputation_values[col] = mode_val
                    df[col] = df[col].fillna(mode_val)
                else:
                    median_val = df[col].median() if not pd.isna(df[col].median()) else 0.0
                    self.imputation_values[col] = median_val
                    df[col] = df[col].fillna(median_val)
        else:
            for col, fill_val in self.imputation_values.items():
                if col in df.columns:
                    df[col] = df[col].fillna(fill_val)

        missing_after = df.isnull().sum().to_dict()
        preprocessing_report['missing_after'] = missing_after

        # 4. Outlier Detection (IQR) & Capping (Winsorization)
        outlier_stats = {}
        target_num_cols = ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount']
        for col in target_num_cols:
            if col in df.columns:
                if is_training:
                    q1 = df[col].quantile(0.25)
                    q3 = df[col].quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = max(0.0, float(q1 - 1.5 * iqr))
                    upper_bound = float(q3 + 1.5 * iqr)
                    self.iqr_bounds[col] = (lower_bound, upper_bound)
                else:
                    lower_bound, upper_bound = self.iqr_bounds.get(col, (df[col].min(), df[col].max()))

                # Count outliers before capping
                outliers_count = int(((df[col] < lower_bound) | (df[col] > upper_bound)).sum())
                outlier_stats[col] = {
                    'q1': round(float(df[col].quantile(0.25)), 2),
                    'q3': round(float(df[col].quantile(0.75)), 2),
                    'lower_bound': round(lower_bound, 2),
                    'upper_bound': round(upper_bound, 2),
                    'outliers_detected': outliers_count
                }
                # Cap / Winsorize outliers
                df[col] = np.clip(df[col], lower_bound, upper_bound)

        preprocessing_report['outlier_stats'] = outlier_stats

        # Keep a copy of cleaned dataframe before scaling/encoding for EDA
        cleaned_df_for_eda = df.copy()

        # 5. Categorical Encoding
        # Standardize Target variable if present
        if self.TARGET_COL in df.columns:
            df[self.TARGET_COL] = df[self.TARGET_COL].map(lambda x: 1 if str(x).strip().upper() in ['Y', 'YES', '1', 'APPROVED'] else 0)

        # Categorical features
        cat_cols = [c for c in self.CATEGORICAL_COLS if c in df.columns]
        for col in cat_cols:
            df[col] = df[col].astype(str)
            if is_training:
                le = LabelEncoder()
                df[col] = le.fit_transform(df[col])
                self.label_encoders[col] = le
            else:
                le = self.label_encoders.get(col)
                if le:
                    classes = list(le.classes_)
                    df[col] = df[col].map(lambda s: le.transform([s])[0] if s in classes else 0)

        # 6. Feature Scaling
        num_cols = [c for c in self.NUMERICAL_COLS if c in df.columns]
        if is_training:
            self.scaler = StandardScaler()
            df[num_cols] = self.scaler.fit_transform(df[num_cols])
        else:
            if self.scaler:
                df[num_cols] = self.scaler.transform(df[num_cols])

        return df, cleaned_df_for_eda, preprocessing_report

    def generate_eda_charts(self, cleaned_df):
        """Generates dynamic EDA plots as Base64 strings for web presentation."""
        charts = {}
        df = cleaned_df.copy()

        # Chart 1: Target Variable Distribution
        if self.TARGET_COL in df.columns:
            fig, ax = plt.subplots(figsize=(6, 4))
            status_counts = df[self.TARGET_COL].value_counts()
            labels = ['Approved (Y)' if str(k) in ['Y', '1'] else 'Rejected (N)' for k in status_counts.index]
            colors = ['#10b981', '#ef4444']
            bars = ax.bar(labels, status_counts.values, color=colors, edgecolor='none', width=0.5)
            ax.set_title("Loan Status Distribution", fontsize=14, fontweight='bold', pad=12)
            ax.set_ylabel("Applicant Count", fontsize=11)
            for bar in bars:
                height = bar.get_height()
                ax.annotate(f'{height} ({height/len(df)*100:.1f}%)',
                            xy=(bar.get_x() + bar.get_width() / 2, height),
                            xytext=(0, 4), textcoords="offset points",
                            ha='center', va='bottom', fontsize=10, fontweight='bold')
            ax.grid(axis='y', linestyle='--', alpha=0.5)
            charts['target_distribution'] = self._fig_to_base64(fig)

        # Chart 2: Feature Distributions (Histograms & KDE for Income & Loan Amount)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        if 'ApplicantIncome' in df.columns:
            sns.histplot(df['ApplicantIncome'], kde=True, ax=axes[0], color='#3b82f6', bins=25)
            axes[0].set_title("Applicant Income Distribution", fontsize=12, fontweight='bold')
            axes[0].set_xlabel("Income ($)", fontsize=10)
        if 'LoanAmount' in df.columns:
            sns.histplot(df['LoanAmount'], kde=True, ax=axes[1], color='#8b5cf6', bins=25)
            axes[1].set_title("Loan Amount Distribution ($k)", fontsize=12, fontweight='bold')
            axes[1].set_xlabel("Loan Amount ($k)", fontsize=10)
        charts['feature_distributions'] = self._fig_to_base64(fig)

        # Chart 3: Box Plots (Outlier visualization)
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        if 'ApplicantIncome' in df.columns and self.TARGET_COL in df.columns:
            sns.boxplot(x=self.TARGET_COL, y='ApplicantIncome', hue=self.TARGET_COL, data=df, ax=axes[0], palette=['#ef4444', '#10b981'], legend=False)
            axes[0].set_title("Income by Loan Status (Box Plot)", fontsize=12, fontweight='bold')
            axes[0].set_xticks([0, 1])
            axes[0].set_xticklabels(['Rejected', 'Approved'])
        if 'LoanAmount' in df.columns and self.TARGET_COL in df.columns:
            sns.boxplot(x=self.TARGET_COL, y='LoanAmount', hue=self.TARGET_COL, data=df, ax=axes[1], palette=['#ef4444', '#10b981'], legend=False)
            axes[1].set_title("Loan Amount by Loan Status", fontsize=12, fontweight='bold')
            axes[1].set_xticks([0, 1])
            axes[1].set_xticklabels(['Rejected', 'Approved'])
        charts['box_plots'] = self._fig_to_base64(fig)

        # Chart 4: Scatter Plot (Income vs Loan Amount)
        if 'ApplicantIncome' in df.columns and 'LoanAmount' in df.columns:
            fig, ax = plt.subplots(figsize=(7, 4.5))
            hue_col = self.TARGET_COL if self.TARGET_COL in df.columns else None
            sns.scatterplot(
                x='ApplicantIncome', y='LoanAmount', hue=hue_col,
                data=df, ax=ax, palette=['#ef4444', '#10b981'] if hue_col else None,
                alpha=0.75, s=45
            )
            ax.set_title("Applicant Income vs Loan Amount", fontsize=13, fontweight='bold', pad=10)
            ax.set_xlabel("Applicant Income ($)", fontsize=11)
            ax.set_ylabel("Loan Amount ($ in thousands)", fontsize=11)
            if hue_col:
                handles, labels = ax.get_legend_handles_labels()
                ax.legend(handles=handles, labels=['Rejected', 'Approved'], title="Loan Status")
            charts['scatter_plot'] = self._fig_to_base64(fig)

        # Chart 5: Correlation Heatmap
        # Build numeric/encoded correlation
        numeric_sub_df = df.copy()
        if self.TARGET_COL in numeric_sub_df.columns:
            numeric_sub_df[self.TARGET_COL] = numeric_sub_df[self.TARGET_COL].map(
                lambda x: 1 if str(x).strip().upper() in ['Y', 'YES', '1', 'APPROVED'] else 0
            )
        for col in self.CATEGORICAL_COLS:
            if col in numeric_sub_df.columns and numeric_sub_df[col].dtype == 'object':
                le = LabelEncoder()
                numeric_sub_df[col] = le.fit_transform(numeric_sub_df[col].astype(str))

        num_corr_cols = [c for c in numeric_sub_df.columns if c not in self.IRRELEVANT_COLS and np.issubdtype(numeric_sub_df[c].dtype, np.number)]
        if len(num_corr_cols) > 1:
            fig, ax = plt.subplots(figsize=(8.5, 6))
            corr = numeric_sub_df[num_corr_cols].corr()
            sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0, ax=ax, cbar=True, square=True)
            ax.set_title("Correlation Heatmap Matrix", fontsize=13, fontweight='bold', pad=12)
            charts['correlation_heatmap'] = self._fig_to_base64(fig)

        return charts

    def train_models(self, processed_df):
        """
        Trains and evaluates ML models (Random Forest, Logistic Regression, Decision Tree).
        Calculates Accuracy, Precision, Recall, F1-Score, Confusion Matrix, and ROC-AUC.
        """
        if self.TARGET_COL not in processed_df.columns:
            raise ValueError(f"Target column '{self.TARGET_COL}' not found in dataset.")

        X = processed_df.drop(columns=[self.TARGET_COL])
        y = processed_df[self.TARGET_COL]
        self.feature_columns = list(X.columns)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        models = {
            "Random Forest": RandomForestClassifier(n_estimators=120, max_depth=6, random_state=42),
            "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
            "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=42)
        }

        results = {}
        best_model_name = None
        best_f1 = -1
        best_clf = None

        for name, clf in models.items():
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            y_prob = clf.predict_proba(X_test)[:, 1] if hasattr(clf, "predict_proba") else y_pred

            acc = float(accuracy_score(y_test, y_pred))
            prec = float(precision_score(y_test, y_pred, zero_division=0))
            rec = float(recall_score(y_test, y_pred, zero_division=0))
            f1 = float(f1_score(y_test, y_pred, zero_division=0))
            auc = float(roc_auc_score(y_test, y_prob))
            cm = confusion_matrix(y_test, y_pred).tolist()
            report = classification_report(y_test, y_pred, output_dict=True)

            results[name] = {
                'accuracy': round(acc * 100, 2),
                'precision': round(prec * 100, 2),
                'recall': round(rec * 100, 2),
                'f1_score': round(f1 * 100, 2),
                'roc_auc': round(auc * 100, 2),
                'confusion_matrix': cm,
                'classification_report': report
            }

            if f1 > best_f1:
                best_f1 = f1
                best_model_name = name
                best_clf = clf

        self.trained_model = best_clf
        self.model_name = best_model_name
        self.metrics = results

        # Feature Importance (from Random Forest)
        rf_model = models["Random Forest"]
        importances = rf_model.feature_importances_
        feature_importance_dict = {
            col: round(float(imp) * 100, 2)
            for col, imp in sorted(zip(self.feature_columns, importances), key=lambda x: x[1], reverse=True)
        }
        self.feature_importances = feature_importance_dict

        # Feature Importance Chart
        fig, ax = plt.subplots(figsize=(7.5, 4.5))
        sorted_features = list(feature_importance_dict.keys())[::-1]
        sorted_vals = list(feature_importance_dict.values())[::-1]
        bars = ax.barh(sorted_features, sorted_vals, color='#4f46e5', height=0.6)
        ax.set_title(f"Feature Importance ({best_model_name})", fontsize=13, fontweight='bold', pad=10)
        ax.set_xlabel("Relative Importance (%)", fontsize=11)
        for bar in bars:
            width = bar.get_width()
            ax.annotate(f'{width:.1f}%',
                        xy=(width, bar.get_y() + bar.get_height() / 2),
                        xytext=(4, 0), textcoords="offset points",
                        ha='left', va='center', fontsize=9, fontweight='bold')
        importance_chart_b64 = self._fig_to_base64(fig)

        # Best Model Confusion Matrix Chart
        best_cm = np.array(results[best_model_name]['confusion_matrix'])
        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        sns.heatmap(best_cm, annot=True, fmt='d', cmap='Blues', cbar=False,
                    xticklabels=['Predicted Reject', 'Predicted Approve'],
                    yticklabels=['Actual Reject', 'Actual Approve'], ax=ax)
        ax.set_title(f"Confusion Matrix ({best_model_name})", fontsize=12, fontweight='bold', pad=10)
        cm_chart_b64 = self._fig_to_base64(fig)

        # Save artifacts
        self.save_pipeline()

        return {
            'model_comparisons': results,
            'best_model': best_model_name,
            'feature_importances': feature_importance_dict,
            'importance_chart': importance_chart_b64,
            'confusion_matrix_chart': cm_chart_b64
        }

    def save_pipeline(self):
        """Saves pipeline state & artifacts with joblib."""
        pipeline_data = {
            'model': self.trained_model,
            'model_name': self.model_name,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'feature_columns': self.feature_columns,
            'feature_importances': self.feature_importances,
            'iqr_bounds': self.iqr_bounds,
            'imputation_values': self.imputation_values,
            'metrics': self.metrics
        }
        joblib.dump(pipeline_data, self.model_path)
        print(f"Pipeline model successfully saved to: {self.model_path}")

    def load_pipeline(self):
        """Loads saved pipeline artifact."""
        if not os.path.exists(self.model_path):
            return False
        pipeline_data = joblib.load(self.model_path)
        self.trained_model = pipeline_data['model']
        self.model_name = pipeline_data['model_name']
        self.scaler = pipeline_data['scaler']
        self.label_encoders = pipeline_data['label_encoders']
        self.feature_columns = pipeline_data['feature_columns']
        self.feature_importances = pipeline_data.get('feature_importances', {})
        self.iqr_bounds = pipeline_data.get('iqr_bounds', {})
        self.imputation_values = pipeline_data.get('imputation_values', {})
        self.metrics = pipeline_data.get('metrics', {})
        return True

    def predict_single(self, input_dict):
        """
        Real-time inference function for custom inputs.
        Returns prediction status, probability confidence, and underwriting factors.
        """
        if self.trained_model is None:
            loaded = self.load_pipeline()
            if not loaded:
                raise ValueError("Model pipeline is not yet trained or loaded.")

        row = {}
        for col in self.feature_columns:
            val = input_dict.get(col, None)
            if val is None or val == '':
                val = self.imputation_values.get(col, 0)
            row[col] = val

        df_input = pd.DataFrame([row])

        # Apply outlier clipping for numericals
        for col, (low, high) in self.iqr_bounds.items():
            if col in df_input.columns:
                df_input[col] = pd.to_numeric(df_input[col], errors='coerce').fillna(self.imputation_values.get(col, 0))
                df_input[col] = np.clip(df_input[col], low, high)

        # Apply categorical encoding
        for col, le in self.label_encoders.items():
            if col in df_input.columns:
                val_str = str(df_input[col].iloc[0])
                if val_str in le.classes_:
                    df_input[col] = le.transform([val_str])[0]
                else:
                    df_input[col] = 0

        # Apply scaling
        num_cols = [c for c in self.NUMERICAL_COLS if c in df_input.columns]
        if self.scaler:
            df_input[num_cols] = self.scaler.transform(df_input[num_cols])

        # Align columns
        df_input = df_input[self.feature_columns]

        # Predict
        pred = self.trained_model.predict(df_input)[0]
        prob_arr = self.trained_model.predict_proba(df_input)[0] if hasattr(self.trained_model, "predict_proba") else [0.5, 0.5]
        approval_prob = round(float(prob_arr[1]) * 100, 2)
        rejection_prob = round(float(prob_arr[0]) * 100, 2)

        # Dynamic risk assessment explanation
        risk_factors = []
        positive_factors = []

        credit_hist = float(input_dict.get('Credit_History', 1.0))
        if credit_hist == 1.0:
            positive_factors.append("Applicant has a verified, positive credit history record (major approval factor).")
        else:
            risk_factors.append("Applicant does not meet standard credit history guidelines (high risk indicator).")

        app_inc = float(input_dict.get('ApplicantIncome', 0))
        coapp_inc = float(input_dict.get('CoapplicantIncome', 0))
        tot_inc = app_inc + coapp_inc
        loan_amt_k = float(input_dict.get('LoanAmount', 100))

        if tot_inc > 0 and loan_amt_k > 0:
            ratio = tot_inc / (loan_amt_k * 10)
            if ratio >= 2.5:
                positive_factors.append(f"Strong debt-to-income buffer: Total monthly income (${tot_inc:,.0f}) supports loan amount (${loan_amt_k * 1000:,.0f}).")
            elif ratio < 1.0:
                risk_factors.append(f"Elevated debt ratio: Requested loan (${loan_amt_k * 1000:,.0f}) is high compared to total income (${tot_inc:,.0f}).")

        if str(input_dict.get('Education')) == 'Graduate':
            positive_factors.append("Higher educational attainment favorable for applicant stability.")

        return {
            'is_approved': bool(pred == 1),
            'status': "Approved" if pred == 1 else "Rejected",
            'confidence': approval_prob if pred == 1 else rejection_prob,
            'approval_probability': approval_prob,
            'rejection_probability': rejection_prob,
            'risk_factors': risk_factors,
            'positive_factors': positive_factors,
            'model_used': self.model_name
        }
