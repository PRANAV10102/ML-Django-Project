#!/bin/bash
set -e

# Change directory to project root
cd "$(dirname "$0")"

echo "=========================================================="
echo " Starting DataMine ML Django Application"
echo " Project Directory: $(pwd)"
echo "=========================================================="

# Activate virtual environment
if [ -d "venv" ]; then
    echo "Activating virtual environment..."
    source venv/bin/activate
else
    echo "Error: Virtual environment 'venv' not found."
    exit 1
fi

# Run migrations if needed
python manage.py migrate --no-input

# Start development server
echo ""
echo "🚀 Application is running at:"
echo "👉 http://127.0.0.1:8000/"
echo ""
echo "Press Ctrl+C to stop the server."
echo "=========================================================="

python manage.py runserver 127.0.0.1:8000

