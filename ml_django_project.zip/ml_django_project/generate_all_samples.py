import os
import random
import numpy as np
import pandas as pd

def create_dataset_variant(
    name,
    n_samples=650,
    file_type="csv",
    approval_bias=0.0,
    income_mean=8.4,
    income_sigma=0.65,
    loan_scale=0.022,
    urban_pct=0.33,
    rural_pct=0.29,
    grad_pct=0.78,
    good_credit_pct=0.82,
    missing_rate=0.04,
    outlier_rate=0.05,
    duplicate_count=5,
    seed=42,
    output_dir="sample_data"
):
    np.random.seed(seed)
    random.seed(seed)
    os.makedirs(output_dir, exist_ok=True)

    loan_ids = [f"LP{str(i).zfill(6)}" for i in range(1001, 1001 + n_samples)]

    genders = np.random.choice(["Male", "Female", None], size=n_samples, p=[0.78, 0.19, 0.03])
    married = np.random.choice(["Yes", "No", None], size=n_samples, p=[0.65, 0.33, 0.02])
    dependents = np.random.choice(["0", "1", "2", "3+", None], size=n_samples, p=[0.55, 0.18, 0.17, 0.08, 0.02])
    education = np.random.choice(["Graduate", "Not Graduate"], size=n_samples, p=[grad_pct, 1.0 - grad_pct])
    self_employed = np.random.choice(["No", "Yes", None], size=n_samples, p=[0.80, 0.15, 0.05])

    # Applicant Income
    applicant_income = np.random.lognormal(mean=income_mean, sigma=income_sigma, size=n_samples).astype(int)
    # Inject outliers
    outlier_idx = np.random.choice(n_samples, size=int(n_samples * outlier_rate), replace=False)
    applicant_income[outlier_idx] = (applicant_income[outlier_idx] * np.random.uniform(2.5, 5.0, size=len(outlier_idx))).astype(int)

    # Coapplicant Income
    has_coapplicant = np.random.choice([0, 1], size=n_samples, p=[0.45, 0.55])
    coapplicant_income = (np.random.lognormal(mean=income_mean - 1.1, sigma=0.75, size=n_samples) * has_coapplicant).astype(int)

    # Loan Amount (in thousands)
    total_income = applicant_income + coapplicant_income
    base_loan = (total_income * np.random.uniform(loan_scale * 0.8, loan_scale * 1.2, size=n_samples)).astype(int)
    loan_amount = np.clip(base_loan, 15, 750)
    # Missing values injection
    loan_amount = [val if random.random() > missing_rate else None for val in loan_amount]

    # Term
    term_choices = [12, 36, 60, 84, 120, 180, 240, 300, 360, 480]
    term_probs = [0.005, 0.005, 0.01, 0.01, 0.02, 0.08, 0.04, 0.03, 0.76, 0.04]
    loan_term = np.random.choice(term_choices, size=n_samples, p=term_probs)
    loan_term = [val if random.random() > missing_rate else None for val in loan_term]

    # Credit History
    credit_choices = [1.0, 0.0, None]
    credit_probs = [good_credit_pct, 1.0 - good_credit_pct - 0.05, 0.05]
    credit_history = np.random.choice(credit_choices, size=n_samples, p=credit_probs)

    # Property Area
    semiurban_pct = max(0.01, 1.0 - (urban_pct + rural_pct))
    property_area = np.random.choice(["Urban", "Semiurban", "Rural"], size=n_samples, p=[urban_pct, semiurban_pct, rural_pct])

    # Loan Status
    loan_status = []
    for i in range(n_samples):
        score = approval_bias
        ch = credit_history[i]
        if ch == 1.0:
            score += 3.4
        elif ch == 0.0:
            score -= 3.2
        else:
            score += 0.4

        tot_inc = applicant_income[i] + coapplicant_income[i]
        amt = loan_amount[i] if loan_amount[i] is not None else 140
        ratio = tot_inc / (amt * 10.0 + 1)
        if ratio > 2.0:
            score += 1.3
        elif ratio < 0.8:
            score -= 1.2

        if education[i] == "Graduate":
            score += 0.4
        if property_area[i] == "Semiurban":
            score += 0.5
        elif property_area[i] == "Rural":
            score -= 0.3
        if married[i] == "Yes":
            score += 0.3

        prob = 1.0 / (1.0 + np.exp(-(score + np.random.normal(0, 0.55))))
        loan_status.append("Y" if prob >= 0.5 else "N")

    df = pd.DataFrame({
        "Loan_ID": loan_ids,
        "Gender": genders,
        "Married": married,
        "Dependents": dependents,
        "Education": education,
        "Self_Employed": self_employed,
        "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income,
        "LoanAmount": loan_amount,
        "Loan_Amount_Term": loan_term,
        "Credit_History": credit_history,
        "Property_Area": property_area,
        "Loan_Status": loan_status
    })

    if duplicate_count > 0:
        dups = df.sample(n=duplicate_count, random_state=seed)
        df = pd.concat([df, dups], ignore_index=True)

    filename = f"{name}.{file_type}"
    file_path = os.path.join(output_dir, filename)
    if file_type == "xlsx":
        df.to_excel(file_path, index=False)
    else:
        df.to_csv(file_path, index=False)

    print(f"Generated {filename}: {len(df)} records, {len(df.columns)} features.")
    return file_path

def generate_all_samples():
    output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_data")
    
    # 1. Standard Balanced Dataset (650 rows, CSV)
    create_dataset_variant(
        name="sample_1_standard_loan_data",
        n_samples=650,
        file_type="csv",
        seed=101,
        output_dir=output_dir
    )

    # 2. Commercial & Enterprise Lending (1,200 rows, XLSX)
    create_dataset_variant(
        name="sample_2_commercial_enterprise_loans",
        n_samples=1200,
        file_type="xlsx",
        income_mean=9.2,
        income_sigma=0.75,
        loan_scale=0.035,
        grad_pct=0.88,
        urban_pct=0.50,
        rural_pct=0.15,
        seed=202,
        output_dir=output_dir
    )

    # 3. High-Risk / Subprime Market (750 rows, CSV)
    create_dataset_variant(
        name="sample_3_subprime_high_risk_loans",
        n_samples=750,
        file_type="csv",
        approval_bias=-1.2,
        good_credit_pct=0.48,
        missing_rate=0.07,
        outlier_rate=0.08,
        seed=303,
        output_dir=output_dir
    )

    # 4. Tech & Urban Graduates Portfolio (600 rows, CSV)
    create_dataset_variant(
        name="sample_4_tech_urban_graduates",
        n_samples=600,
        file_type="csv",
        approval_bias=0.8,
        grad_pct=0.96,
        income_mean=8.9,
        urban_pct=0.70,
        rural_pct=0.10,
        good_credit_pct=0.90,
        seed=404,
        output_dir=output_dir
    )

    # 5. Rural Microfinance & Agri Loans (850 rows, XLSX)
    create_dataset_variant(
        name="sample_5_rural_microfinance_loans",
        n_samples=850,
        file_type="xlsx",
        income_mean=7.8,
        income_sigma=0.55,
        loan_scale=0.015,
        urban_pct=0.10,
        rural_pct=0.75,
        grad_pct=0.55,
        seed=505,
        output_dir=output_dir
    )

    # 6. Messy Data Mining Stress-Test (950 rows, CSV)
    create_dataset_variant(
        name="sample_6_messy_noisy_benchmark",
        n_samples=950,
        file_type="csv",
        missing_rate=0.14,
        outlier_rate=0.12,
        duplicate_count=18,
        seed=606,
        output_dir=output_dir
    )

if __name__ == "__main__":
    generate_all_samples()

