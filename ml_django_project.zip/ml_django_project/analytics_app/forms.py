from django import forms

class DatasetUploadForm(forms.Form):
    dataset_file = forms.FileField(
        label="Upload Raw Dataset (.csv or .xlsx)",
        help_text="Upload a CSV or Excel file containing loan approval data (minimum 500+ records recommended)",
        widget=forms.ClearableFileInput(attrs={
            'class': 'form-control',
            'accept': '.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'
        })
    )

class LoanPredictionForm(forms.Form):
    GENDER_CHOICES = [('Male', 'Male'), ('Female', 'Female')]
    MARRIED_CHOICES = [('Yes', 'Yes'), ('No', 'No')]
    DEPENDENTS_CHOICES = [('0', '0'), ('1', '1'), ('2', '2'), ('3+', '3+')]
    EDUCATION_CHOICES = [('Graduate', 'Graduate'), ('Not Graduate', 'Not Graduate')]
    SELF_EMPLOYED_CHOICES = [('No', 'No'), ('Yes', 'Yes')]
    CREDIT_HISTORY_CHOICES = [(1.0, 'Meets Guidelines (1.0 - Good)'), (0.0, 'Does Not Meet (0.0 - Bad/Default)')]
    PROPERTY_AREA_CHOICES = [('Urban', 'Urban'), ('Semiurban', 'Semiurban'), ('Rural', 'Rural')]

    Gender = forms.ChoiceField(
        choices=GENDER_CHOICES, initial='Male',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    Married = forms.ChoiceField(
        choices=MARRIED_CHOICES, initial='Yes',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    Dependents = forms.ChoiceField(
        choices=DEPENDENTS_CHOICES, initial='0',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    Education = forms.ChoiceField(
        choices=EDUCATION_CHOICES, initial='Graduate',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    Self_Employed = forms.ChoiceField(
        choices=SELF_EMPLOYED_CHOICES, initial='No',
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    ApplicantIncome = forms.FloatField(
        label="Applicant Monthly Income ($)",
        initial=5400,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 5000', 'min': 0, 'step': 100})
    )
    CoapplicantIncome = forms.FloatField(
        label="Coapplicant Monthly Income ($)",
        initial=1500,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 1500', 'min': 0, 'step': 100})
    )
    LoanAmount = forms.FloatField(
        label="Requested Loan Amount (in thousands $)",
        initial=140,
        help_text="140 = $140,000",
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 140', 'min': 10, 'step': 5})
    )
    Loan_Amount_Term = forms.FloatField(
        label="Loan Term Duration (months)",
        initial=360,
        widget=forms.Select(choices=[
            (360, '360 months (30 Years)'),
            (240, '240 months (20 Years)'),
            (180, '180 months (15 Years)'),
            (120, '120 months (10 Years)'),
            (60, '60 months (5 Years)')
        ], attrs={'class': 'form-select'})
    )
    Credit_History = forms.ChoiceField(
        label="Credit History Standing",
        choices=CREDIT_HISTORY_CHOICES, initial=1.0,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    Property_Area = forms.ChoiceField(
        choices=PROPERTY_AREA_CHOICES, initial='Semiurban',
        widget=forms.Select(attrs={'class': 'form-select'})
    )

