from django import template

register = template.Library()

@register.filter(name='dict_key')
def dict_key(d, k):
    """Safely retrieves d[k] in django templates."""
    if isinstance(d, dict):
        return d.get(k, '')
    return ''

