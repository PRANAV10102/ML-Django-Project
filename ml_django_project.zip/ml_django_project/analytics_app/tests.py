import os
import json
from django.test import TestCase, Client
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from django.conf import settings
from loan_ml_core.pipeline import LoanMLPipeline

class LoanAnalyticsTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.sample_csv_path = os.path.join(settings.BASE_DIR, 'sample_data', 'loan_approval_dataset.csv')

    def test_pipeline_core(self):
        """Part 1: Test Data Mining & ML Pipeline logic"""
        pipeline = LoanMLPipeline()
        self.assertTrue(os.path.exists(self.sample_csv_path), "Sample CSV must exist")
        df = pipeline.load_data(self.sample_csv_path)
        self.assertGreaterEqual(len(df), 500, "Dataset must have at least 500 records")

        # Initial Summary
        summary = pipeline.get_initial_summary(df)
        self.assertIn('total_rows', summary)
        self.assertIn('missing_total', summary)

        # Preprocessing
        processed_df, cleaned_df, prep_report = pipeline.preprocess_pipeline(df, is_training=True)
        self.assertEqual(prep_report['duplicates_removed'], 4)
        self.assertIn('ApplicantIncome', prep_report['outlier_stats'])
        self.assertNotIn('Loan_ID', processed_df.columns, "Irrelevant column should be dropped")

        # EDA Charts
        charts = pipeline.generate_eda_charts(cleaned_df)
        self.assertIn('target_distribution', charts)
        self.assertIn('correlation_heatmap', charts)

        # Model Training & Evaluation
        results = pipeline.train_models(processed_df)
        self.assertIn(results['best_model'], results['model_comparisons'])
        best_acc = results['model_comparisons'][results['best_model']]['accuracy']
        self.assertGreaterEqual(best_acc, 75.0, "Model accuracy should be solid")

        # Inference
        pred = pipeline.predict_single({
            'Gender': 'Male',
            'Married': 'Yes',
            'Dependents': '0',
            'Education': 'Graduate',
            'Self_Employed': 'No',
            'ApplicantIncome': 6000,
            'CoapplicantIncome': 2000,
            'LoanAmount': 130,
            'Loan_Amount_Term': 360,
            'Credit_History': 1.0,
            'Property_Area': 'Urban'
        })
        self.assertIn('status', pred)
        self.assertIn('confidence', pred)

    def test_web_flow(self):
        """Part 2: Test Django Web Views and Endpoints"""
        # 1. Test Index view
        res = self.client.get(reverse('index'))
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, "1. File Upload Interface")

        # 2. Test Quick Load Sample Dataset
        res_sample = self.client.get(reverse('load_sample_dataset'), follow=True)
        self.assertEqual(res_sample.status_code, 200)
        self.assertContains(res_sample, "2. Data Summary Preview & Mining Report")

        # 3. Test Summary View
        res_sum = self.client.get(reverse('summary'))
        self.assertEqual(res_sum.status_code, 200)
        self.assertContains(res_sum, "Missing Values Handling")
        self.assertContains(res_sum, "Outlier Detection & IQR Capping")

        # 4. Test Visual Analytics Dashboard
        res_eda = self.client.get(reverse('eda'))
        self.assertEqual(res_eda.status_code, 200)
        self.assertContains(res_eda, "Visual Analytics Dashboard")

        # 5. Test Model Evaluation View
        res_model = self.client.get(reverse('model_eval'))
        self.assertEqual(res_model.status_code, 200)
        self.assertContains(res_model, "Model Performance Comparison Matrix")
        self.assertContains(res_model, "Confusion Matrix")

        # 6. Test Interactive Prediction Form GET & POST
        res_pred_get = self.client.get(reverse('predict'))
        self.assertEqual(res_pred_get.status_code, 200)

        post_data = {
            'Gender': 'Male',
            'Married': 'Yes',
            'Dependents': '1',
            'Education': 'Graduate',
            'Self_Employed': 'No',
            'ApplicantIncome': 5200,
            'CoapplicantIncome': 1800,
            'LoanAmount': 140,
            'Loan_Amount_Term': 360,
            'Credit_History': 1.0,
            'Property_Area': 'Semiurban'
        }
        res_pred_post = self.client.post(reverse('predict'), data=post_data)
        self.assertEqual(res_pred_post.status_code, 200)
        self.assertContains(res_pred_post, "Real-Time Underwriting Result")

        # 7. Test API Prediction JSON
        res_api = self.client.post(
            reverse('api_predict'),
            data=json.dumps(post_data),
            content_type='application/json'
        )
        self.assertEqual(res_api.status_code, 200)
        json_resp = res_api.json()
        self.assertTrue(json_resp['success'])
        self.assertIn('status', json_resp['result'])

