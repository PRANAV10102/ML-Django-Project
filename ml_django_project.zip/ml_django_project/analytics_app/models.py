from django.db import models

class DatasetUpload(models.Model):
    file = models.FileField(upload_to='datasets/')
    filename = models.CharField(max_length=255)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    row_count = models.IntegerField(default=0)
    col_count = models.IntegerField(default=0)
    is_processed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.filename} ({self.uploaded_at.strftime('%Y-%m-%d %H:%M')})"

class PredictionLog(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    applicant_income = models.FloatField()
    coapplicant_income = models.FloatField(default=0.0)
    loan_amount = models.FloatField()
    loan_term = models.FloatField()
    credit_history = models.FloatField()
    gender = models.CharField(max_length=20)
    married = models.CharField(max_length=10)
    education = models.CharField(max_length=30)
    property_area = models.CharField(max_length=30)
    prediction = models.CharField(max_length=20)
    confidence = models.FloatField()

    def __str__(self):
        return f"Prediction: {self.prediction} ({self.confidence}%) at {self.created_at.strftime('%H:%M:%S')}"

