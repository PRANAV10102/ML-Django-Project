from django.urls import path, re_path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('load-sample/', views.load_sample_dataset, name='load_sample_dataset'),
    re_path(r'^load-sample/(?P<filename>[^/]+)/?$', views.load_sample_dataset, name='load_sample_dataset_file'),
    re_path(r'^download-sample/(?P<filename>[^/]+)/?$', views.download_sample_dataset, name='download_sample_dataset'),
    path('download-zip/', views.download_project_zip, name='download_project_zip'),
    path('summary/', views.summary, name='summary'),
    path('eda/', views.eda_dashboard, name='eda'),
    path('model-evaluation/', views.model_evaluation, name='model_eval'),
    path('predict/', views.predict, name='predict'),
    path('api/predict/', views.api_predict, name='api_predict'),
]
