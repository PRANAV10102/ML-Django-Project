import os
import json
import pandas as pd
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from django.http import JsonResponse, FileResponse, Http404
from django.views.decorators.csrf import csrf_exempt

from .models import DatasetUpload, PredictionLog
from .forms import DatasetUploadForm, LoanPredictionForm
from loan_ml_core.pipeline import LoanMLPipeline

# Singleton pipeline instance for web application
_pipeline_instance = None

SAMPLE_DATASETS_META = [
    {
        'id': 'sample_1',
        'name': 'Standard Loan Approval Dataset',
        'filename': 'sample_1_standard_loan_data.csv',
        'format': 'CSV',
        'rows': 655,
        'badge_class': 'bg-primary-subtle text-primary border-primary',
        'description': 'Balanced benchmark dataset with realistic credit profiles, demographics, and standard approval distribution (~68% approved).'
    },
    {
        'id': 'sample_2',
        'name': 'Commercial & Enterprise Lending Portfolio',
        'filename': 'sample_2_commercial_enterprise_loans.xlsx',
        'format': 'Excel (.xlsx)',
        'rows': 1205,
        'badge_class': 'bg-success-subtle text-success border-success',
        'description': 'Large-scale portfolio with higher income tiers ($8k - $35k), higher loan amounts ($200k+), and corporate applicants.'
    },
    {
        'id': 'sample_3',
        'name': 'Subprime & High-Risk Default Market',
        'filename': 'sample_3_subprime_high_risk_loans.csv',
        'format': 'CSV',
        'rows': 755,
        'badge_class': 'bg-danger-subtle text-danger border-danger',
        'description': 'Macroeconomic stress-test scenario featuring elevated rejection rates (~52%), lower credit histories, and higher variance.'
    },
    {
        'id': 'sample_4',
        'name': 'Tech Professionals & Urban Graduates',
        'filename': 'sample_4_tech_urban_graduates.csv',
        'format': 'CSV',
        'rows': 605,
        'badge_class': 'bg-info-subtle text-info border-info',
        'description': 'Predominantly Urban (70%) and Graduate (96%) applicants with high tech salaries and lower requested loan durations.'
    },
    {
        'id': 'sample_5',
        'name': 'Rural Microfinance & Agricultural Credit',
        'filename': 'sample_5_rural_microfinance_loans.xlsx',
        'format': 'Excel (.xlsx)',
        'rows': 855,
        'badge_class': 'bg-warning-subtle text-warning border-warning',
        'description': 'Rural agricultural development loans (75% Rural) with micro-loan sizes ($15k - $120k) and high self-employment.'
    },
    {
        'id': 'sample_6',
        'name': 'Messy Real-World Data Mining Benchmark',
        'filename': 'sample_6_messy_noisy_benchmark.csv',
        'format': 'CSV',
        'rows': 968,
        'badge_class': 'bg-secondary text-dark border-secondary',
        'description': 'Stress-test dataset containing 18 duplicate records, 14% missing values, and extreme outliers up to $80,000 income to test preprocessing.'
    }
]

def get_pipeline():
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = LoanMLPipeline()
        if not _pipeline_instance.load_pipeline():
            # If not yet trained, train on bundled dataset
            sample_csv = os.path.join(settings.BASE_DIR, 'sample_data', 'sample_1_standard_loan_data.csv')
            if not os.path.exists(sample_csv):
                sample_csv = os.path.join(settings.BASE_DIR, 'sample_data', 'loan_approval_dataset.csv')
            if os.path.exists(sample_csv):
                df = _pipeline_instance.load_data(sample_csv)
                proc_df, _, _ = _pipeline_instance.preprocess_pipeline(df, is_training=True)
                _pipeline_instance.train_models(proc_df)
    return _pipeline_instance

def index(request):
    """File Upload Interface & Dataset Selection"""
    pipeline = get_pipeline()

    if request.method == 'POST':
        form = DatasetUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['dataset_file']
            filename = uploaded_file.name

            # Validate extension
            if not (filename.endswith('.csv') or filename.endswith('.xlsx') or filename.endswith('.xls')):
                messages.error(request, "Invalid file format. Please upload a .csv or .xlsx file.")
                return render(request, 'index.html', {'form': form, 'sample_datasets': SAMPLE_DATASETS_META})

            # Save uploaded file
            upload_record = DatasetUpload.objects.create(
                file=uploaded_file,
                filename=filename
            )

            try:
                # Load dataset
                file_path = upload_record.file.path
                df = pipeline.load_data(file_path)

                if len(df) < 50:
                    messages.warning(request, f"Uploaded dataset has {len(df)} records. Recommended: 500+ records for reliable data mining.")

                # Generate initial summary
                initial_summary = pipeline.get_initial_summary(df)

                # Execute preprocessing
                processed_df, cleaned_df, prep_report = pipeline.preprocess_pipeline(df, is_training=True)

                # Generate EDA charts
                charts = pipeline.generate_eda_charts(cleaned_df)

                # Train ML models & evaluate
                training_results = pipeline.train_models(processed_df)

                # Update database record
                upload_record.row_count = len(df)
                upload_record.col_count = len(df.columns)
                upload_record.is_processed = True
                upload_record.save()

                # Save state in session
                request.session['dataset_name'] = filename
                request.session['initial_summary'] = initial_summary
                request.session['prep_report'] = prep_report
                request.session['charts'] = charts
                request.session['training_results'] = training_results

                messages.success(request, f"Successfully uploaded and analyzed '{filename}' ({len(df)} records)!")
                return redirect('summary')

            except Exception as e:
                messages.error(request, f"Error processing dataset: {str(e)}")
                return render(request, 'index.html', {'form': form, 'sample_datasets': SAMPLE_DATASETS_META})
    else:
        form = DatasetUploadForm()

    recent_uploads = DatasetUpload.objects.order_by('-uploaded_at')[:5]
    return render(request, 'index.html', {
        'form': form,
        'recent_uploads': recent_uploads,
        'sample_datasets': SAMPLE_DATASETS_META
    })

def load_sample_dataset(request, filename=None):
    """Loads any of the 6 pre-packaged sample datasets"""
    pipeline = get_pipeline()
    
    target_filename = filename or request.GET.get('file', 'sample_1_standard_loan_data.csv')
    sample_file_path = os.path.join(settings.BASE_DIR, 'sample_data', target_filename)

    # Fallback to standard loan dataset if specific file not found
    if not os.path.exists(sample_file_path):
        sample_file_path = os.path.join(settings.BASE_DIR, 'sample_data', 'loan_approval_dataset.csv')
        target_filename = 'loan_approval_dataset.csv'

    if not os.path.exists(sample_file_path):
        messages.error(request, f"Dataset file '{target_filename}' not found.")
        return redirect('index')

    try:
        df = pipeline.load_data(sample_file_path)
        initial_summary = pipeline.get_initial_summary(df)
        processed_df, cleaned_df, prep_report = pipeline.preprocess_pipeline(df, is_training=True)
        charts = pipeline.generate_eda_charts(cleaned_df)
        training_results = pipeline.train_models(processed_df)

        request.session['dataset_name'] = target_filename
        request.session['initial_summary'] = initial_summary
        request.session['prep_report'] = prep_report
        request.session['charts'] = charts
        request.session['training_results'] = training_results

        messages.success(request, f"Dataset '{target_filename}' ({len(df)} records) loaded and processed successfully!")
        return redirect('summary')
    except Exception as e:
        messages.error(request, f"Error loading dataset: {str(e)}")
        return redirect('index')

def download_sample_dataset(request, filename):
    """Allows downloading sample dataset files for testing upload"""
    file_path = os.path.join(settings.BASE_DIR, 'sample_data', filename)
    if not os.path.exists(file_path):
        raise Http404("Sample file not found")
    
    content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if filename.endswith('.xlsx') else 'text/csv'
    return FileResponse(open(file_path, 'rb'), as_attachment=True, filename=filename, content_type=content_type)

def download_project_zip(request):
    """Allows 1-click downloading of the complete project zip archive"""
    zip_path = os.path.join(settings.BASE_DIR, 'ml_django_project.zip')
    if not os.path.exists(zip_path):
        zip_path = os.path.join(settings.BASE_DIR, '..', 'ml_django_project.zip')
    if not os.path.exists(zip_path):
        raise Http404("Project zip archive not found")
    return FileResponse(open(zip_path, 'rb'), as_attachment=True, filename='ml_django_project.zip', content_type='application/zip')

def summary(request):
    """Data Summary Preview: Basic info, preview table, missing values count, outlier stats"""
    initial_summary = request.session.get('initial_summary')
    prep_report = request.session.get('prep_report')
    dataset_name = request.session.get('dataset_name', "Default Loan Dataset")

    # If session is empty, auto-load standard sample dataset
    if not initial_summary or not prep_report:
        return redirect('load_sample_dataset')

    # Compute missing count before vs after for table presentation
    missing_comparison = []
    missing_before = prep_report.get('missing_before', {})
    missing_after = prep_report.get('missing_after', {})
    for col in initial_summary.get('columns', []):
        if col in missing_before:
            missing_comparison.append({
                'column': col,
                'type': initial_summary['column_types'].get(col, 'Unknown'),
                'before': missing_before.get(col, 0),
                'after': missing_after.get(col, 0),
                'imputation': 'Median (Numerical)' if col in LoanMLPipeline.NUMERICAL_COLS else ('Mode (Categorical)' if col in LoanMLPipeline.CATEGORICAL_COLS else 'Retained')
            })

    context = {
        'dataset_name': dataset_name,
        'summary': initial_summary,
        'prep_report': prep_report,
        'missing_comparison': missing_comparison,
        'outlier_stats': prep_report.get('outlier_stats', {}),
        'preview_rows': initial_summary.get('preview_rows', []),
        'columns': initial_summary.get('columns', []),
    }
    return render(request, 'summary.html', context)

def eda_dashboard(request):
    """Visual Analytics Dashboard: Dynamic charts for distributions, correlations, outliers"""
    charts = request.session.get('charts')
    dataset_name = request.session.get('dataset_name', "Loan Dataset")

    if not charts:
        return redirect('load_sample_dataset')

    training_results = request.session.get('training_results', {})
    if 'importance_chart' in training_results:
        charts['feature_importance'] = training_results['importance_chart']

    return render(request, 'eda.html', {
        'dataset_name': dataset_name,
        'charts': charts
    })

def model_evaluation(request):
    """Model Training & Prediction Results: Metrics, Comparison, Confusion Matrix, Classification Report"""
    training_results = request.session.get('training_results')
    dataset_name = request.session.get('dataset_name', "Loan Dataset")

    if not training_results:
        return redirect('load_sample_dataset')

    best_model_name = training_results.get('best_model')
    model_comparisons = training_results.get('model_comparisons', {})
    best_model_metrics = model_comparisons.get(best_model_name, {})

    # Extract classification report classes (0 and 1)
    clf_report = best_model_metrics.get('classification_report', {})
    report_rows = []
    for key, values in clf_report.items():
        if isinstance(values, dict):
            label = "Rejected (Class 0)" if key == '0' else ("Approved (Class 1)" if key == '1' else key.replace('_', ' ').title())
            report_rows.append({
                'label': label,
                'precision': round(values.get('precision', 0) * 100, 1),
                'recall': round(values.get('recall', 0) * 100, 1),
                'f1': round(values.get('f1-score', 0) * 100, 1),
                'support': values.get('support', 0)
            })

    context = {
        'dataset_name': dataset_name,
        'training_results': training_results,
        'best_model_name': best_model_name,
        'best_model_metrics': best_model_metrics,
        'model_comparisons': model_comparisons,
        'confusion_matrix_chart': training_results.get('confusion_matrix_chart'),
        'importance_chart': training_results.get('importance_chart'),
        'feature_importances': training_results.get('feature_importances', {}),
        'report_rows': report_rows
    }
    return render(request, 'model_eval.html', context)

def predict(request):
    """Interactive Real-time Prediction Section with custom inputs"""
    pipeline = get_pipeline()
    prediction_result = None

    if request.method == 'POST':
        form = LoanPredictionForm(request.POST)
        if form.is_valid():
            input_data = form.cleaned_data
            try:
                prediction_result = pipeline.predict_single(input_data)

                # Save prediction to history log
                PredictionLog.objects.create(
                    applicant_income=input_data.get('ApplicantIncome', 0),
                    coapplicant_income=input_data.get('CoapplicantIncome', 0),
                    loan_amount=input_data.get('LoanAmount', 0),
                    loan_term=input_data.get('Loan_Amount_Term', 360),
                    credit_history=float(input_data.get('Credit_History', 1.0)),
                    gender=input_data.get('Gender', 'Male'),
                    married=input_data.get('Married', 'Yes'),
                    education=input_data.get('Education', 'Graduate'),
                    property_area=input_data.get('Property_Area', 'Semiurban'),
                    prediction=prediction_result['status'],
                    confidence=prediction_result['confidence']
                )
            except Exception as e:
                messages.error(request, f"Error generating prediction: {str(e)}")
    else:
        # Prepopulate with standard realistic inputs
        form = LoanPredictionForm()

    recent_predictions = PredictionLog.objects.order_by('-created_at')[:8]

    return render(request, 'predict.html', {
        'form': form,
        'prediction_result': prediction_result,
        'recent_predictions': recent_predictions,
        'model_name': pipeline.model_name
    })

@csrf_exempt
def api_predict(request):
    """JSON API endpoint for real-time predictions"""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST method required'}, status=405)

    try:
        data = json.loads(request.body)
        pipeline = get_pipeline()
        result = pipeline.predict_single(data)
        return JsonResponse({'success': True, 'result': result})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)
