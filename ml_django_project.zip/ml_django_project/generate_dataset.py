import os
import random
import numpy as np
import pandas as pd

def generate_loan_dataset(n_samples=650, output_dir=None, seed=42):
    np.random.seed(seed)
    random.seed(seed)

    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(output_dir, exist_ok=True)

    loan_ids = [f"LP{str(i).zfill(6)}" for i in range(1001, 1001 + n_samples)]

    # Demographics and applicant profile
    genders = np.random.choice(["Male", "Female", None], size=n_samples, p=[0.79, 0.18, 0.03])
    married = np.random.choice(["Yes", "No", None], size=n_samples, p=[0.64, 0.34, 0.02])
    dependents = np.random.choice(["0", "1", "2", "3+", None], size=n_samples, p=[0.56, 0.17, 0.17, 0.08, 0.02])
    education = np.random.choice(["Graduate", "Not Graduate"], size=n_samples, p=[0.78, 0.22])
    self_employed = np.random.choice(["No", "Yes", None], size=n_samples, p=[0.81, 0.14, 0.05])

    # Financials (with realistic log-normal distributions & some extreme outliers)
    applicant_income = np.random.lognormal(mean=8.4, sigma=0.65, size=n_samples).astype(int)
    # Inject a few high outliers
    outlier_idx = np.random.choice(n_samples, size=int(n_samples * 0.05), replace=False)
    applicant_income[outlier_idx] = (applicant_income[outlier_idx] * np.random.uniform(2.5, 4.5, size=len(outlier_idx))).astype(int)

    # Coapplicant income (some 0, some positive)
    has_coapplicant = np.random.choice([0, 1], size=n_samples, p=[0.45, 0.55])
    coapplicant_income = (np.random.lognormal(mean=7.3, sigma=0.8, size=n_samples) * has_coapplicant).astype(int)

    # Loan Amount (in thousands) - related to income
    total_income = applicant_income + coapplicant_income
    base_loan = (total_income * np.random.uniform(0.018, 0.028, size=n_samples)).astype(int)
    loan_amount = np.clip(base_loan, 20, 700)
    # Introduce some missing values
    loan_amount = [val if random.random() > 0.04 else None for val in loan_amount]

    # Loan Amount Term (in months) - mostly 360, some 180, 240, 480
    term_choices = [12, 36, 60, 84, 120, 180, 240, 300, 360, 480]
    term_probs = [0.005, 0.005, 0.01, 0.01, 0.02, 0.08, 0.04, 0.03, 0.76, 0.04]
    loan_term = np.random.choice(term_choices, size=n_samples, p=term_probs)
    loan_term = [val if random.random() > 0.03 else None for val in loan_term]

    # Credit History: 1.0 (meets guidelines) or 0.0 (does not meet)
    credit_history = np.random.choice([1.0, 0.0, None], size=n_samples, p=[0.82, 0.12, 0.06])

    # Property Area
    property_area = np.random.choice(["Urban", "Semiurban", "Rural"], size=n_samples, p=[0.33, 0.38, 0.29])

    # Realistic Loan Status logic based on credit history, income-to-loan ratio, education, property area
    loan_status = []
    for i in range(n_samples):
        score = 0.0
        # Credit history is the dominant factor in loan underwriting
        ch = credit_history[i]
        if ch == 1.0:
            score += 3.5
        elif ch == 0.0:
            score -= 3.0
        else:
            score += 0.5  # neutral if missing

        # Capacity to pay (Total income vs loan amount)
        tot_inc = applicant_income[i] + coapplicant_income[i]
        amt = loan_amount[i] if loan_amount[i] is not None else 140
        ratio = tot_inc / (amt * 10.0 + 1)
        if ratio > 2.0:
            score += 1.2
        elif ratio < 0.8:
            score -= 1.0

        if education[i] == "Graduate":
            score += 0.4

        if property_area[i] == "Semiurban":
            score += 0.5
        elif property_area[i] == "Rural":
            score -= 0.3

        if married[i] == "Yes":
            score += 0.3

        # Add stochastic noise
        prob = 1.0 / (1.0 + np.exp(-(score + np.random.normal(0, 0.6))))
        status = "Y" if prob >= 0.5 else "N"
        loan_status.append(status)

    df = pd.DataFrame({
        "Loan_ID": loan_ids,
        "Gender": genders,
        "Married": married,
        "Dependents": dependents,
        "Education": education,
        "Self_Employed": self_employed,
        "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income,
        "LoanAmount": loan_amount,
        "Loan_Amount_Term": loan_term,
        "Credit_History": credit_history,
        "Property_Area": property_area,
        "Loan_Status": loan_status
    })

    # Add duplicate rows (3-5 duplicates) to demonstrate data cleaning requirements
    duplicates = df.sample(n=4, random_state=42)
    df = pd.concat([df, duplicates], ignore_index=True)

    csv_path = os.path.join(output_dir, "loan_approval_dataset.csv")
    xlsx_path = os.path.join(output_dir, "loan_approval_dataset.xlsx")

    df.to_csv(csv_path, index=False)
    df.to_excel(xlsx_path, index=False)

    print(f"Dataset generated successfully with {len(df)} records.")
    print(f"Saved CSV: {csv_path}")
    print(f"Saved Excel: {xlsx_path}")
    return csv_path, xlsx_path

if __name__ == "__main__":
    generate_loan_dataset()

