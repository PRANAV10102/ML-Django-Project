# Data Mining & Machine Learning Pipeline with Django Web Interface
### Mini Project: Loan Approval Prediction & Analytics Dashboard

This project is an end-to-end Machine Learning and Data Mining system paired with a responsive Django web application for interactive dataset analysis, visualization, and real-time underwriting prediction.

---

## 📁 6 Pre-Packaged Benchmark Datasets

Located in [`sample_data/`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data) for testing file uploads and live pipeline analytics:

| # | Dataset File | Format | Records | Key Characteristics & Scenario |
|---|---|---|---|---|
| **1** | [`sample_1_standard_loan_data.csv`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_1_standard_loan_data.csv) | **CSV** | 655 rows | **Balanced Benchmark**: Standard Kaggle distribution with ~68% approval rate, standard demographic spreads, and verified credit histories. |
| **2** | [`sample_2_commercial_enterprise_loans.xlsx`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_2_commercial_enterprise_loans.xlsx) | **Excel (.xlsx)** | 1,205 rows | **Commercial & Enterprise Lending**: High applicant incomes ($8k - $35k) and requested loan sizes ($200k+) in corporate urban centers. |
| **3** | [`sample_3_subprime_high_risk_loans.csv`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_3_subprime_high_risk_loans.csv) | **CSV** | 755 rows | **Subprime & High-Risk Default**: Macroeconomic stress scenario with elevated rejection rates (~52%), defaults, and lower credit ratings. |
| **4** | [`sample_4_tech_urban_graduates.csv`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_4_tech_urban_graduates.csv) | **CSV** | 605 rows | **Tech & Urban Graduates**: 96% Graduate rate, 70% Urban property location, high income-to-loan ratios, and accelerated loan tenures. |
| **5** | [`sample_5_rural_microfinance_loans.xlsx`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_5_rural_microfinance_loans.xlsx) | **Excel (.xlsx)** | 855 rows | **Rural Microfinance & Agri Credit**: 75% Rural property location with micro-lending amounts ($15k - $120k) and agricultural self-employed borrowers. |
| **6** | [`sample_6_messy_noisy_benchmark.csv`](file:///Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/sample_data/sample_6_messy_noisy_benchmark.csv) | **CSV** | 968 rows | **Data Mining Stress-Test**: Contains 18 duplicate rows, 14% missing values, and extreme outliers up to $80,000 to rigorously test cleaning and IQR Winsorization. |

---

## 🔬 Part 1: Data Mining & ML Pipeline (Backend Logic)

### 1. Dataset Selection & Ingestion
- Minimum 500+ records requirement satisfied (all sample datasets contain between 605 and 1,205 rows).
- Includes both numerical and categorical attributes.

### 2. Data Preprocessing (Data Mining Techniques)
- **Handling Missing Values**: Audits null values; imputes via **Median** for numerical features and **Mode** for categorical features.
- **Outlier Treatment**: Detected using **Interquartile Range (IQR)**: $[Q1 - 1.5 \times IQR, Q3 + 1.5 \times IQR]$. Bounded using **Winsorization / Capping** to preserve data points while preventing distortion.
- **Data Cleaning**: Deduplication (removes duplicate records) and drops irrelevant identifiers (`Loan_ID`).
- **Data Transformation**: Feature scaling using `StandardScaler` ($z = \frac{x - \mu}{\sigma}$) and categorical encoding via `LabelEncoder`.
- **Feature Selection & Importance**: Pearson correlation matrix and Gini feature importances computed via tree-based estimators.

### 3. Exploratory Data Analysis (EDA) & Dynamic Visualizations
- Target variable distribution (Approved vs. Rejected counts and percentages).
- Distribution histograms with overlaid Kernel Density Estimation (KDE) curves.
- Box plots comparing quartiles across loan status before and after outlier capping.
- Multi-attribute scatter plots (`ApplicantIncome` vs. `LoanAmount` segmented by `Loan_Status`).
- Annotated correlation matrix heatmap.

### 4. Model Training & Multi-Metric Evaluation
- Trains and compares: **Random Forest Classifier**, **Logistic Regression**, and **Decision Tree Classifier**.
- Evaluated using **Accuracy**, **Precision**, **Recall**, **F1-Score**, **ROC-AUC**, **Confusion Matrix**, and **Classification Report**.
- Serialized pipeline artifact using `joblib` in `trained_models/loan_model_pipeline.joblib`.

---

## 🌐 Part 2: Django Web Application (User Interface)

1. **File Upload Interface (`/`)**:
   - Drag-and-drop file upload for `.csv` and `.xlsx` datasets.
   - **Sample Datasets Hub**: Card listing all 6 pre-packaged datasets with direct download links and 1-click **"Load Directly"** buttons.
2. **Data Summary Preview (`/summary/`)**:
   - High-level KPI summary cards (Total Records, Attributes, Duplicates Removed, Nulls Imputed).
   - Interactive preview table (top 10 rows).
   - Missing values audit table and IQR outlier capping audit table.
3. **Visual Analytics Dashboard (`/eda/`)**:
   - Responsive dynamic charts generated via Matplotlib and Seaborn with automated mining insights.
4. **Prediction / Result Section**:
   - **Model Metrics (`/model-evaluation/`)**: Model comparison matrix, best-model badge, Confusion Matrix heatmap, and classification report.
   - **Real-Time Prediction (`/predict/`)**: Interactive form for custom inputs with instant underwriting decisions (`LOAN APPROVED` / `LOAN REJECTED`), confidence scores, and risk factors.

---

## 🚀 Quick Start Guide

### 1. Launch the Server
An executable script is provided:
```bash
cd /Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project
./run.sh
```

### 2. Access the Application
Open your browser at:
👉 **`http://127.0.0.1:8000/`**

### 3. Run Automated Tests
```bash
/Users/pranavkuumar/.gemini/antigravity/scratch/ml_django_project/venv/bin/python3 manage.py test
```
